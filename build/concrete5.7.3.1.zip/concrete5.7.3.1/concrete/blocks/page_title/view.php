<?php  defined('C5_EXECUTE') or die("Access Denied."); ?>
<h1 class="page-title"><?php echo $title?></h1>