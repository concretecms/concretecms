This is a block used for embedding video files for playback. It uses [the native ie9+ HTML video tag](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video) when supported
and falls back to an FLV player made by [Chris Brimelow](http://chrisbrimelow.com/blog/?p=15).

This fallback is discussed [here](https://github.com/concrete5/concrete5/issues/3497).
