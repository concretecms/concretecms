<?php

return [
    'trackers' => [
        'core_stack' => \Concrete\Core\Page\Stack\UsageTracker::class,
        'core_file' => \Concrete\Core\File\Tracker\UsageTracker::class
    ]
];
